import { create } from 'zustand';

// Zustand store to manage full user info
export const useChatItemStore = create((set) => ({
    userInfo: {
        id: null,
        name: '',
        surname: '',
        birthday: '',
        phoneNumber: '',
        position: null,
        role: '',
        status: false,
        img: '',
        whereLive: '',
        whereStudy: '',
        languages: '',
        mail: '',
        login: '',
    },

    // Function to update user info
    setUserInfo: (newUserInfo) => set({ userInfo: newUserInfo }),

    // Function to clear/reset user info
    clearUserInfo: () => set({
        userInfo: {
            id: null,
            name: '',
            surname: '',
            birthday: '',
            phoneNumber: '',
            position: null,
            role: '',
            status: false,
            img: '',
            whereLive: '',
            whereStudy: '',
            languages: '',
            mail: '',
            login: '',
        }
    }),
}));

