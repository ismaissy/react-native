
import React, { useEffect, useState } from 'react';
import {
    View, Text, ActivityIndicator, StyleSheet,
    Alert, FlatList, RefreshControl, TouchableOpacity, TextInput
} from 'react-native';
import User from './User';
import { Link, Stack, useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { API } from '../config';
import { router } from 'expo-router';
import Product from './Product';

// $ yarn add @react-navigation/native @react-navigation/native-stack react-native-screens react-native-safe-area-context react-native-gesture-handler

const MainScreen = () => {
    const [isLoading, setIsLoading] = useState(true);
    const [users, setUsers] = useState(null);
    const [login, setLogin] = useState('');
    const [password, setPassword] = useState('');
    const [searchText, setSearchText] = useState('');
    const [filteredUsers, setFilteredUsers] = useState([]);

    const router = useRouter();  // <-- Вызов хука useRouter в компоненте

    const fetchGetUsers = () => {
        setIsLoading(true)
        // fetch('http://192.168.1.138/api/user/users')
        fetch(API + '/api/user/users')
            .then((response) => response.json())
            .then((data) => setUsers(data))
            .catch((error) => Alert.alert("Ошибка", 'Ошибка при загрузке данных:'))
            .finally(() => {
                setIsLoading(false)
                router.push("/Home")
            })
    }


    useEffect(fetchGetUsers, []);

    if (isLoading) {
        return (
            <View style={{
                flex: 1,
                justifyContent: 'center',
                alignItems: "center"
            }}>
                <ActivityIndicator size="large" />
                <Text style={{ marginTop: 15 }}>Downloading...</Text>
            </View>
        )
    }

    const onClick = (name, surname, img) => {

        router.push({
            pathname: "/UserItem",
            params: { name, surname, img }
        });
    }


    const handleSearch = (text) => {
        setSearchText(text);
        const filtered = users.filter(user =>
            `${user.name} ${user.surname}`.toLowerCase().includes(text.toLowerCase())
        );
        setFilteredUsers(filtered);
    };
    return (
       <View style={{ flex: 1, padding: 10 }}>
            <TextInput
                value={searchText}
                onChangeText={handleSearch}
                placeholder="Поиск..."
                style={{
                    height: 40,
                    borderColor: '#ccc',
                    borderWidth: 1,
                    borderRadius: 8,
                    paddingHorizontal: 10,
                    marginBottom: 10,
                }}
            />

            <FlatList
                refreshControl={<RefreshControl refreshing={isLoading} onRefresh={fetchGetUsers} />}
                data={users}
                renderItem={({ item }) =>
                    <TouchableOpacity
                        style={{ flex: 1, margin: 5 }} // 👈 важно
                        onPress={() => onClick(item.name, item.surname, item.img)}>
                        <Product name={item.name} surname={item.surname} img={item.img} />
                    </TouchableOpacity>
                }
                keyExtractor={(item, index) => index.toString()}
                numColumns={2} // 👈 выводим 2 колонки
                contentContainerStyle={{ padding: 10 }} // 👈 выводим 2 колонки
            />
        </View>
    );
}

export default MainScreen