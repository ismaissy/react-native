import { Button, Image, StyleSheet, Text, TextInput, View } from 'react-native'
import React, { useEffect, useState } from 'react'
import io from "socket.io-client";
import { useRouter, useLocalSearchParams, Stack } from 'expo-router'; // Корректные импорты
import { FlatList } from 'react-native-gesture-handler';
import { useUserStore } from '../store/store';
import { API } from '../config';



const socket = io(API + ":5022");

const ProfileHeaderScreen = ({ img, opposideUserName }) => {
    return (
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Image
                source={img ? { uri: `${API}/images/${img}` } : require('../assets/icons/profile.png')}
                style={{ width: 30, height: 30, borderRadius: 15, marginRight: 10 }}
            />
            <Text style={{ fontSize: 18 }}>{`Профиль ${opposideUserName}`}</Text>
        </View>
    );
};


const ChatItem = () => {
    const userInfo = useUserStore((state) => state.userInfo);
    const [selectChatHistory, setSelectChatHistory] = useState([])
    const params = useLocalSearchParams();
    const { img, recipient, opposideUserName, chatId, oppositeSenderId, oppositeReceiverId, oppositeChatId, receiverId, senderId } = params;
    const [message, setMessage] = useState('');
    console.log(chatId)

    const getChats = (senderId, chatId) => {
        socket.emit('getchat', { chatId, senderId });
        socket.on('getchat', (data) => {
            const { chatHistory } = data;
            console.log(data)
            setSelectChatHistory(chatHistory)
        });
        return () => socket.off('getchat');
    };


    console.log("userInfo item ", userInfo)
    useEffect(() => {
        socket.emit('register', userInfo.id);
        socket.on('message', (data) => {
            const { senderId, receiverId, text } = data;
            setSelectChatHistory((prevMessages) => [...prevMessages, { senderId: Number(senderId), receiverId, text }])
        });
        getChats(senderId, chatId);


        return () => socket.off('message');
    }, [userInfo.id, chatId])

    const sendMessage = (e) => {
        e.preventDefault();
        // socket.emit('message', { senderId: currentUser, recipientId: recipient, message, chatId, oppositeChatId, oppositeSenderId, oppositeReceiverId });
        if (message) {
            socket.emit('message', { senderId: userInfo.id, recipientId: recipient, message, chatId, oppositeChatId, oppositeSenderId, oppositeReceiverId });
            // socket.emit('message', {
            //     senderId,
            //     recipientId: opposideUserId,
            //     message,
            //     chatId,
            //     oppositeChatId: opposideChatId,
            //     oppositeSenderId,
            //     oppositeReceiverId
            // });
            setMessage("");
        }
    };
    // const sendMessage = () => {
    //     // if (message.trim()) {
    //     //     // Отправляем сообщение через сокет
    //     //     socket.emit('message', {
    //     //         senderId: userInfo.id,
    //     //         receiverId: /* ID получателя */,
    //     //         text: message,
    //     //     });

    //     //     // Очищаем поле ввода после отправки
    //     //     setMessage('');
    //     // }
    //     console.log(message)
    //     setMessage('');
    // };
    return (
        <>
            <Stack.Screen options={{ headerTitle: () => (< ProfileHeaderScreen img={img} opposideUserName={opposideUserName} />) }} />

            <FlatList
                data={selectChatHistory}
                keyExtractor={(item, index) => index.toString()}
                renderItem={({ item }) => (
                    <View
                        style={[
                            styles.messageContainer,
                            { justifyContent: item.senderId === userInfo.id ? 'flex-end' : 'flex-start' }
                        ]}
                    >
                        <View
                            style={[
                                styles.messageBubble,
                                { backgroundColor: item.senderId === userInfo.id ? '#D0E7FF' : '#D4F8E8' }
                            ]}
                        >
                            {/* {item.senderId !== userInfo.id && (
                                <Text style={styles.senderName}>{userInfo.name}</Text>
                            )} */}
                            <Text style={styles.messageText}>{item.text}</Text>
                        </View>
                    </View>
                )}
            />


            <View style={styles.inputContainer}>
                <TextInput
                    style={styles.input}
                    value={message}
                    onChangeText={setMessage}
                    placeholder="Введите сообщение..."
                />
                <Button title="Отправить" onPress={sendMessage} />
            </View>
        </>
    )
}

export default ChatItem


const styles = StyleSheet.create({
    inputContainer: {
        flexDirection: 'row',
        padding: 10,
        alignItems: 'center',
    },
    input: {
        flex: 1,
        borderColor: '#ccc',
        borderWidth: 1,
        padding: 10,
        borderRadius: 10,
        marginRight: 10,
    },
    img: {
        width: 30,
        height: 30,
        justifyContent: "center",
        alignItems: "center",
        borderRadius: 15,
    },
    name: {
        fontSize: 18
    },

    headerChat: {
        gap: 10,
        height: "10%",
        backgroundColor: "white",
        paddingTop: "5%",
        paddingLeft: "5%",
        display: 'flex',
        flexDirection: 'row'
    },
    messageContainer: {
        flexDirection: 'row',
        marginVertical: 5,
    },
    messageBubble: {
        marginLeft: 20,
        marginRight: 20,
        padding: 10,
        borderRadius: 10,
        maxWidth: '75%',
    },
    senderName: {
        fontWeight: 'bold',
        marginBottom: 5,
    },
    messageText: {
        fontSize: 16,
    },
});