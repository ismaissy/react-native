import { View, Text, Image, StyleSheet, } from 'react-native';
import { API } from '../config';



export default function Product({ name, surname, img, price }) {

    return (<>
        <View style={styles.card}>
            {img ? (
                <Image
                    source={{ uri: `${API}/images/${img}` }}
                    style={styles.imgMe}
                />
            ) : (
                <View style={styles.placeholder}>
                    <Text style={styles.placeholderText}>
                        {name ? name.charAt(0).toUpperCase() : '?'}
                    </Text>
                </View>
            )}
            {/* <View > */}
            <View style={styles.textContainer}>
                <Text style={styles.mainText}>{name || 'Без имени'}</Text>
                <Text style={styles.secondText}>{surname || 'Без фамилии'}</Text>
                <Text style={styles.secondText}>{price || ' '}</Text>
            </View>
        </View>
    </>);
}

const styles = StyleSheet.create({
    card: {
        backgroundColor: '#fff',
        borderRadius: 8,
        padding: 10,
        marginBottom: 10,
        width: '100%', 
        elevation: 3,
    },
    imgMe: {
        width: "100%",
        height: 100,
        borderRadius: 5,
    },
    placeholder: {
        width: '100%',
        height: 100,
        borderRadius: 5,
        backgroundColor: '#ccc',
        alignItems: 'center',
        justifyContent: 'center',
    },
    placeholderText: {
        fontSize: 30,
        color: '#fff',
    },
    textContainer: {
        marginTop: 10,
        alignItems: 'left',
    },
    mainText: {
        fontWeight: 'bold',
    },
    secondText: {
        color: '#555',
    },
});
