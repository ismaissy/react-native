import { Image, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { Link } from 'expo-router'
import MainScreen from './MainScreen'
import LoginInput from './Login'
import { StatusBar } from 'expo-status-bar'
import { SafeAreaView } from 'react-native-safe-area-context'

const Rootlayout = () => {
    return (
        <SafeAreaView>
            {/* <LoginInput style={styles.login} /> */}
            <MainScreen />
            {/* <Link href="/Home">Go link</Link> */}
            <StatusBar style="auto" />
        </SafeAreaView>
    )
}

export default Rootlayout

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',  // Center content vertically
        alignItems: 'center',      // Center content horizontally
    },
    login: {
        marginTop: 50,
    },


});