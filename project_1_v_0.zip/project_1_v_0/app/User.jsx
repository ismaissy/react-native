import { View, Text, Image, StyleSheet, } from 'react-native';
import { API } from '../config';



export default function User({ name, surname, img }) {

    return (<>
        <View style={styles.card}>
            {img ? (
                <Image
                    source={{ uri: `${API}/images/${img}` }}
                    style={styles.imgMe}
                />
            ) : (
                <View style={styles.placeholder}>
                    <Text style={styles.placeholderText}>
                        {name ? name.charAt(0).toUpperCase() : '?'}
                    </Text>
                </View>
            )}
            <View style={styles.textContainer}>
                <Text style={styles.name}>{name || 'Без имени'}</Text>
                <Text style={styles.surname}>{surname || 'Без фамилии'}</Text>
            </View>
        </View>
    </>);
}

const styles = StyleSheet.create({
    card: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 10,
        marginVertical: 10,
        backgroundColor: '#f0f0f0',
        borderRadius: 10,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.3,
        shadowRadius: 5,
    },
    imgMe: {
        width: 80,
        height: 80,
        borderRadius: 40,
        marginRight: 15,
    },
    placeholder: {
        width: 80,
        height: 80,
        borderRadius: 40,
        backgroundColor: '#ccc',
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 15,
    },
    placeholderText: {
        fontSize: 30,
        color: '#fff',
    },
    textContainer: {
        flexDirection: 'column',
    },
    name: {
        fontSize: 18,
        fontWeight: 'bold',
    },
    surname: {
        fontSize: 16,
        color: '#666',
    },
});

