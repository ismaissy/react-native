import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
import { useRouter, useLocalSearchParams, Stack } from 'expo-router'; // Корректные импорты
import { API } from '../config';

const UserItem = () => {
    const params = useLocalSearchParams(); // Извлекаем параметры через этот хук

    const { name, surname, img, birthday } = params;

    console.log(params)

    return (
        <>
            <Stack.Screen options={{ title: `Профиль ${name}` }} />

            <View style={styles.card}>
                {img ? (
                    <Image
                        source={{ uri: `${API}/images/${img}` }}
                        style={styles.imgMe}
                    />
                ) : (
                    <View style={styles.placeholder}>
                        <Text style={styles.placeholderText}>
                            {name ? name.charAt(0).toUpperCase() : '?'}
                        </Text>
                    </View>
                )}
                <View style={styles.textContainer}>
                    <Text style={styles.name}>{name || 'Без имени'}</Text>
                    <Text style={styles.surname}>{surname || 'Без фамилии'}</Text>
                    <Text style={styles.surname}>{birthday || 'Без фамилии'}</Text>
                </View>
            </View>

        </>
    );
}



const styles = StyleSheet.create({
    card: {
        padding: 20,
        backgroundColor: '#fff',
        marginBottom: 10,
    },
    imgMe: {
        width: 100,
        height: 100,
        borderRadius: 50,
    },
    placeholder: {
        width: 100,
        height: 100,
        borderRadius: 50,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#ccc',
    },
    placeholderText: {
        fontSize: 40,
        color: '#fff',
    },
    textContainer: {
        marginTop: 10,
    },
    name: {
        fontSize: 18,
        fontWeight: 'bold',
    },
    surname: {
        fontSize: 16,
    },
});

export default UserItem