import { Image, ScrollView, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { useUserStore } from '../../store/store';
import { API } from '../../config';

const Profil = () => {
    const userInfo = useUserStore((state) => state.userInfo);
    return (
        <ScrollView contentContainerStyle={styles.container}>
            {/* Block with photo and name */}
            <View style={styles.header}>
                <View style={styles.profileImageContainer}>
                    {userInfo.img ? (
                        <Image
                            source={{ uri: `${API}/images/${userInfo.img}` }}
                            style={styles.profileImage}
                        />
                    ) : (
                        <Image
                            source={require('../../assets/icons/profile.png')}
                            style={styles.profileImage}
                        />
                    )}
                </View>
                <Text style={styles.name}>
                    {userInfo.name} {userInfo.surname}
                </Text>
                <Text style={styles.position}>
                    {userInfo.position ? userInfo.position.name : 'Not specified'}
                </Text>
            </View>

            {/* Basic Information */}
            <View style={styles.infoSection}>
                <Text style={styles.sectionTitle}>Basic Information</Text>
                <View style={styles.infoRow}>
                    <Text style={styles.label}>Birthday:</Text>
                    <Text style={styles.value}>{userInfo.birthday}</Text>
                </View>
                <View style={styles.infoRow}>
                    <Text style={styles.label}>Phone:</Text>
                    <Text style={styles.value}>{userInfo.phoneNumber}</Text>
                </View>
                <View style={styles.infoRow}>
                    <Text style={styles.label}>Role:</Text>
                    <Text style={styles.value}>{userInfo.role}</Text>
                </View>
                <View style={styles.infoRow}>
                    <Text style={styles.label}>Status:</Text>
                    <Text style={styles.value}>{userInfo.status ? 'Active' : 'Inactive'}</Text>
                </View>
            </View>

            {/* Additional Information */}
            <View style={styles.infoSection}>
                <Text style={styles.sectionTitle}>Additional Information</Text>
                <View style={styles.infoRow}>
                    <Text style={styles.label}>Where Lives:</Text>
                    <Text style={styles.value}>{userInfo.whereLive}</Text>
                </View>
                <View style={styles.infoRow}>
                    <Text style={styles.label}>Where Studied:</Text>
                    <Text style={styles.value}>{userInfo.whereStudy}</Text>
                </View>
                <View style={styles.infoRow}>
                    <Text style={styles.label}>Languages:</Text>
                    <Text style={styles.value}>{userInfo.languages}</Text>
                </View>
                <View style={styles.infoRow}>
                    <Text style={styles.label}>Email:</Text>
                    <Text style={styles.value}>{userInfo.mail}</Text>
                </View>
                {/* <View style={styles.infoRow}>
                    <Text style={styles.label}>Login:</Text>
                    <Text style={styles.value}>{userInfo.login}</Text>
                </View> */}
            </View>
        </ScrollView>
    );
}

export default Profil

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        backgroundColor: '#f5f5f5',
        paddingHorizontal: 20,
        paddingTop: 40,
    },
    header: {
        alignItems: 'center',
        marginBottom: 30,
    },
    profileImageContainer: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.3,
        shadowRadius: 5,
        elevation: 5,
    },
    profileImage: {
        width: 120,
        height: 120,
        borderRadius: 60,
    },
    name: {
        fontSize: 26,
        fontWeight: 'bold',
        color: '#333',
        marginTop: 15,
    },
    position: {
        fontSize: 18,
        color: '#888',
        marginTop: 5,
    },
    infoSection: {
        backgroundColor: '#fff',
        borderRadius: 10,
        padding: 20,
        marginBottom: 20,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 5,
        elevation: 3,
    },
    sectionTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        marginBottom: 10,
        color: '#333',
    },
    infoRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 10,
    },
    label: {
        fontSize: 16,
        color: '#555',
        fontWeight: '600',
    },
    value: {
        fontSize: 16,
        color: '#777',
    },
});
