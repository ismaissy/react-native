// import React from 'react'
// import { SafeAreaView } from 'react-native-safe-area-context'
// import { Image, StyleSheet, Text, View } from 'react-native'
// import { Tabs, Redirect, Stack } from 'expo-router'
// import { RiHome2Fill } from "react-icons/ri";
// import home from "../../assets/icons/home.png"
// import document from "../../assets/icons/document.png"
// import profile from "../../assets/icons/profile.png"
// import setting from "../../assets/icons/bar.png"
// import Setting from './Setting';


// const TabIcon = ({ icon, color, name, focused }) => {
//     return (
//         <View>
//             <Image
//                 style={[styles.TabIconImg, { tintColor: color }]}
//                 source={icon}
//                 resizeMode="contain"
//                 tintColor={color}
//             />
//             <Text style={[styles.TabIconText, { color: color }]}>{name}</Text>
//         </View>
//     )
// }



// const TabsLayout = () => {
//     return (
//         <>
//             <SafeAreaView style={styles.container}>
//                 <Tabs
//                     screenOptions={{
//                         tabBarShowLabel: false,
//                         headerShown: false
//                     }}
//                 >
//                     <Tabs.Screen
//                         name='Profil'
//                         options={{
//                             title: "Profil",
//                             headerShown: false,
//                             tabBarIcon: ({ color, focused }) => (<TabIcon icon={profile} color={color} name={"Profile"} focused={focused} />)
//                         }}
//                     />
//                     <Tabs.Screen
//                         name='Home'
//                         options={{
//                             title: "Home",
//                             headerShown: false,
//                             tabBarIcon: ({ color, focused }) => (<TabIcon icon={home} color={color} name={"Home"} focused={focused} />)
//                         }}
//                     />
//                     <Tabs.Screen
//                         name='Docs'
//                         options={{
//                             title: "Docs",
//                             headerShown: false,
//                             tabBarIcon: ({ color, focused }) => (<TabIcon icon={document} color={color} name={"Docs"} focused={focused} />)
//                         }}
//                     />
//                     <Tabs.Screen
//                         name='Setting'
//                         component={Setting}
//                         options={{
//                             title: "Setting",
//                             headerShown: false,
//                             tabBarIcon: ({ color, focused }) => (<TabIcon icon={setting} color={color} name={"Setting"} focused={focused} />)
//                         }}
//                     />
//                 </Tabs>
//             </SafeAreaView>
//         </>
//     )
// }

// export default TabsLayout

// const styles = StyleSheet.create({
//     container: {
//         backgroundColor: 'white',
//         height: '100%',
//     },
//     TabIconText: {
//         fontSize: 10,
//         marginTop: 2,
//     },
//     TabIconImg: {
//         height: 24,
//         width: 24
//     }
// })
import React from 'react'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Image, StyleSheet, Text, View } from 'react-native'
import { Tabs, Redirect, Stack } from 'expo-router'
import { RiHome2Fill } from "react-icons/ri";
import profile from "../../assets/icons/profile.png";
import home from "../../assets/icons/home.png";
import document from "../../assets/icons/document.png";
import setting from "../../assets/icons/bar.png";
import { useNavigation } from '@react-navigation/native';
const TabIcon = ({ icon, color, name, focused }) => {
  return (
    <View>
      <Image
        style={[styles.TabIconImg, { tintColor: color }]}
        source={icon}
        resizeMode="contain"
        tintColor={color}
      />
      <Text style={[styles.TabIconText, { color: color }]}>{name}</Text>
    </View>
  );
};

const TabsLayout = () => {
  return (
    <SafeAreaView style={styles.container}>
      <Tabs
        screenOptions={{
          tabBarShowLabel: false,
          headerShown: false,
        }}
      >
        <Tabs.Screen
          name="Profil"
          options={{
            title: "Profil",
            headerShown: false,
            tabBarIcon: ({ color, focused }) => (
              <TabIcon icon={profile} color={color} name={"Profile"} focused={focused} />
            ),
          }}
        />
        <Tabs.Screen
          name="Home"
          options={{
            title: "Home",
            headerShown: false,
            tabBarIcon: ({ color, focused }) => (
              <TabIcon icon={home} color={color} name={"Home"} focused={focused} />
            ),
          }}
        />
        <Tabs.Screen
          name="Docs"
          options={{
            title: "Docs",
            headerShown: false,
            tabBarIcon: ({ color, focused }) => (
              <TabIcon icon={document} color={color} name={"Docs"} focused={focused} />
            ),
          }}
        />
        <Tabs.Screen
          name="Setting"
          options={{
            title: "Setting",
            headerShown: false,
            tabBarIcon: ({ color, focused }) => (
              <TabIcon icon={setting} color={color} name={"Setting"} focused={focused} />
            ),
          }}
        />
      </Tabs>
    </SafeAreaView>
  );
};

export default TabsLayout;


const styles = StyleSheet.create({
    container: {
        backgroundColor: 'white',
        height: '100%',
    },
    TabIconText: {
        fontSize: 10,
        marginTop: 2,
    },
    TabIconImg: {
        height: 24,
        width: 24
    }
})
