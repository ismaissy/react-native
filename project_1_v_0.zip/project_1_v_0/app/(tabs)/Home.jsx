import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import MainScreen from '../MainScreen'
import { SafeAreaView } from 'react-native-safe-area-context'

const Home = () => {
  return (

    <MainScreen />

  )
}

export default Home

const styles = StyleSheet.create({})