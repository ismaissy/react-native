import { StyleSheet, Text, View } from 'react-native'

import React from 'react'

const Docs = () => {
    return (
        <View>
            <Text>Docssssss</Text>
        </View>
    )
}

export default Docs

const styles = StyleSheet.create({})