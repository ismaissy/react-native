// import { View, Text, TouchableOpacity, Image, StyleSheet, Modal } from 'react-native'
// import React, { useEffect, useState } from 'react'
// import { FlatList } from 'react-native-gesture-handler';
// import User from '../User';
// import { useUserStore } from '../../store/store';
// import io from "socket.io-client";
// import { useRouter } from 'expo-router';
// import { API } from '../../config';

// const CustomDropdown = ({ users }) => {
//     const [isVisible, setIsVisible] = useState(false);
//     const [selectedValue, setSelectedValue] = useState('Select');

//     const options = ['Option 1', 'Option 2', 'Option 3'];

//     return (
//         <View style={styles.container}>
//             <TouchableOpacity style={styles.dropdown} onPress={() => setIsVisible(true)}>
//                 {/* <Text>{selectedValue}</Text> */}
//                 <Image
//                     source={require('../../assets/icons/addChat.png')}
//                 />
//             </TouchableOpacity>

//             <Modal visible={isVisible} transparent={true} animationType="slide">
//                 <View style={styles.modalContainer}>
//                     <View style={styles.modal}>
//                         {users !== null ? users.map((item, index) => (
//                             <TouchableOpacity
//                                 key={index}
//                                 style={styles.option}
//                                 onPress={() => {
//                                     setSelectedValue(item.name);
//                                     setIsVisible(false);
//                                 }}
//                             >
//                                 <Text>{item.name}</Text>
//                             </TouchableOpacity>
//                         )) : "not found"}
//                     </View>

//                     <View style={styles.modal}>
//                         <TouchableOpacity
//                             key={"vmdkjfnmv"}
//                             //style={styles.option}
//                             onPress={() => setIsVisible(false)}
//                         ><Text>Close</Text>
//                         </TouchableOpacity>
//                     </View>

//                 </View>
//             </Modal>
//         </View>
//     );
// };

// const socket = io("http://192.168.1.138:5022");
// const Chat = () => {
//     const router = useRouter();
//     const userInfo = useUserStore((state) => state.userInfo);


//     //  console.log("userInfo ", userInfo)
//     const [selectChatHistory, setSelectChatHistory] = useState([])
//     const [isLoading, setIsLoading] = useState(true);
//     const [users, setUsers] = useState([]);
//     const [chats, setChats] = useState([]);

//     const fetchChatUsers = async (id) => {
//         try {
//             const response = await fetch(`${API}/api/chat/users/${id}`, {
//                 method: 'GET',
//                 credentials: 'include', // This enables withCredentials
//                 headers: {
//                     'Content-Type': 'application/json',
//                 },
//             });

//             if (!response.ok) {
//                 throw new Error(`Error: ${response.status} ${response.statusText}`);
//             }

//             const data = await response.json();
//             // console.log(data)
//             setUsers(data.users)
//             setChats(data.chats)
//             return data;

//         } catch (error) {
//             console.error('Fetch error:', error);
//             throw error;
//         }
//     };

//     const fetchChatChats = async (id) => {
//         try {
//             const response = await fetch(`${API}/api/chat/chats/${id}`, {
//                 method: 'GET',
//                 credentials: 'include', // This enables withCredentials
//                 headers: {
//                     'Content-Type': 'application/json',
//                 },
//             });

//             if (!response.ok) {
//                 throw new Error(`Error: ${response.status} ${response.statusText}`);
//             }

//             const data = await response.json();
//             console.log(data)
//             return data;

//         } catch (error) {
//             console.error('Fetch error:', error);
//             throw error;
//         }
//     };

//     const getChats = (senderId, chatId) => {
//         socket.emit('getchat', { chatId, senderId });
//         socket.on('getchat', (data) => {
//             const { chatHistory } = data;
//             console.log(data)
//             setSelectChatHistory(chatHistory)
//         });
//         return () => socket.off('getchat');
//     };

//     useEffect(() => {
//         fetchChatUsers(userInfo.id)
//         socket.emit('register', userInfo.id);
//         socket.on('message', (data) => {
//             const { senderId, receiverId, text } = data;

//             setSelectChatHistory((prevMessages) => [...prevMessages, { senderId: Number(senderId), receiverId, text }])
//         });

//         return () => socket.off('message');
//     }, [])

//     //console.log(users)


//     const onSelectChat = (img, recipient, name, chatId, oppositeSenderId, oppositeReceiverId, oppositeChatId, receiverId, senderId) => {
//         socket.off('message');  // Удаляем слушатель 'message'
//         socket.disconnect();
//         router.push({
//             pathname: "/ChatItem",
//             params: { img, recipient, opposideUserName: name, chatId, oppositeSenderId, oppositeReceiverId, oppositeChatId, receiverId, senderId }
//         });
//     }
//     console.log(chats)

//     return (<>
//         <View style={{ flexDirection: 'row', marginTop: 10, marginLeft: 10, }}>
//             <Text>Select user with chat</Text>

//             <CustomDropdown users={users} />




//         </View >
//         <FlatList
//             // refreshControl={<RefreshControl refreshing={isLoading} onRefresh={fetchGetUsers} />}  onPress={() => onSelectChat(item.id, item.chatId, item.img, item.name, item.receiverId, item.opposideChatId)}
//             data={chats}
//             renderItem={({ item }) =>
//                 <TouchableOpacity onPress={() =>
//                     // selectChat(user.id, user.name, user.chatId, user.oppositeSenderId, user.oppositeReceiverId, user.oppositeChatId, user.receiverId, user.senderId)
//                     onSelectChat(item.img, item.id, item.name, item.chatId, item.oppositeSenderId, item.oppositeReceiverId, item.oppositeChatId, item.receiverId, item.senderId)}>
//                     <User name={item.name} surname={item.surname} img={item.img} />
//                 </TouchableOpacity>
//             }
//         />
//     </>
//     )
// }

// const styles = StyleSheet.create({
//     imgMe: {
//         width: 50,
//         height: 50,
//         borderRadius: 20,
//         backgroundColor: "#72a1fa",
//         justifyContent: 'center',
//         alignItems: 'center',
//         marginLeft: 100,

//     },
//     container: {
//         flex: 1,
//         justifyContent: 'center',
//         alignItems: 'center',
//     },
//     dropdown: {
//         padding: 10,
//         borderWidth: 1,
//         borderRadius: 10,
//     },
//     modalContainer: {
//         flex: 1,
//         paddingTop: 100,
//         alignItems: 'center',
//         backgroundColor: 'rgba(0, 0, 0, 0.5)', // Полупрозрачный темный фон для заднего плана
//     },
//     modal: {
//         backgroundColor: 'rgba(255, 255, 255, 0.9)', // Полупрозрачный белый фон для модалки
//         padding: 20,
//         borderRadius: 5,
//         alignSelf: 'center',
//     },
//     option: {
//         padding: 10,
//         borderBottomWidth: 1,
//     },
// });


// export default Chat

// app/(tabs)/Setting.jsx

import { Redirect } from "expo-router";

export default function Setting() {
  return <Redirect href="/(tabs)/settingTabs/" />;
}


