import React from "react";
import { Drawer } from "expo-router/drawer";

const SettingLayout = () => {
  return (
    <Drawer
      screenOptions={{
        headerShown: true,
      }}
    >
      <Drawer.Screen
        name="index"
        options={{ title: "Main Settings" }}
      />
      <Drawer.Screen
        name="ProfileSettings"
        options={{ title: "Profile Settings" }}
      />
      <Drawer.Screen
        name="Notifications"
        options={{ title: "Notifications" }}
      />
    </Drawer>
  );
};

export default SettingLayout;