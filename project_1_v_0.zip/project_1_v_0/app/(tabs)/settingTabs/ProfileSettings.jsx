import React from "react";
import { View, Text } from "react-native";

export default function ProfileSettings() {
  return (
    <View>
      <Text>Настройки профиля</Text>
    </View>
  );
}
