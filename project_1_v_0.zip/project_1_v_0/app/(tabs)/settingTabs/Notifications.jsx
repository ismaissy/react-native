import React from "react";
import { View, Text } from "react-native";

export default function Notifications() {
  return (
    <View>
      <Text>Уведомления</Text>
    </View>
  );
}
