// import React from "react";
// import { View, Text } from "react-native";

// export default function SettingsMain() {
//   return (
//     <View>
//       <Text>Главная страница настроек</Text>
//     </View>
//   );
// }
import { useEffect } from "react";
import { useNavigation } from "@react-navigation/native"; // ✅ обязательно из native
import { DrawerActions } from "@react-navigation/native";

export default function SettingTabsIndex() {
  const navigation = useNavigation();

  useEffect(() => {
    const timeout = setTimeout(() => {
      navigation.dispatch(DrawerActions.openDrawer());
    }, 100); // ⏱ небольшая задержка, чтобы всё успело инициализироваться

    return () => clearTimeout(timeout);
  }, []);

  return null;
}

// import { useEffect } from "react";
// import { useNavigation } from "expo-router";

// export default function SettingTabsIndex() {
//   const navigation = useNavigation();

//   useEffect(() => {
//     navigation.openDrawer();
//   }, []);

//   return null; // Можно вернуть null или содержимое, если нужно
// }
