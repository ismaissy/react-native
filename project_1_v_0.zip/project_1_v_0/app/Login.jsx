import { router } from 'expo-router';
import React, { useEffect, useRef, useState } from 'react';
import { View, TextInput, Button, StyleSheet, Animated, Image, TouchableOpacity, Text } from 'react-native';
import { useUserStore } from '../store/store';

const LoginInput = () => {


    const setUserInfo = useUserStore((state) => state.setUserInfo); // Function to set userInfo

    const [login, setLogin] = useState('');
    const [password, setPassword] = useState('');

    const handleLogin = () => {
        // You can replace this with your login logic

        fetch('http://192.168.1.138:5022/api/user/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ login, pass: password }),
        })
            .then((response) => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then((data) => {

                setUserInfo({
                    id: data.id,
                    name: data.name,
                    surname: data.surname,
                    birthday: data.birthday,
                    phoneNumber: data.phoneNumber,
                    position: data.position,
                    role: data.role,
                    status: data.status,
                    img: data.img,
                    whereLive: data.whereLive,
                    whereStudy: data.whereStudy,
                    languages: data.languages,
                    mail: data.mail,
                    login: data.login,
                });
                router.push("/Home")
                setLogin("")
                setPassword("")

            })
            .catch((error) => {
                console.error('Error:', error);
            });
    };

    const text = "Welcome";
    const animatedValues = useRef(text.split('').map(() => new Animated.Value(0))).current;
    useEffect(() => {
        const animations = animatedValues.map((value, index) => {
            return Animated.timing(value, {
                toValue: 1,
                duration: 500,
                delay: index * 200, // Задержка для каждой буквы
                useNativeDriver: true,
            });
        });

        Animated.stagger(100, animations).start(); // Запуск анимаций с задержкой
    }, [animatedValues]);

    return (
        <>
            <View style={styles.welcome}>
                {text.split('').map((char, index) => (
                    <Animated.Text
                        key={index}
                        style={{
                            ...styles.letter,
                            opacity: animatedValues[index], // Применение анимации прозрачности
                            transform: [{
                                translateY: animatedValues[index].interpolate({
                                    inputRange: [0, 1],
                                    outputRange: [20, 0], // Эффект смещения по вертикали
                                }),
                            }],
                        }}
                    >
                        {char}
                    </Animated.Text>
                ))}
            </View>
            <View style={styles.imageContainer}>
                <Image style={styles.logo} source={require("../assets/main.png")} />
            </View>
            <View style={styles.container}>
                <TextInput
                    style={styles.input}
                    placeholder="Login"
                    value={login}
                    onChangeText={setLogin}
                    autoCapitalize="none"
                />
                <TextInput
                    style={styles.input}
                    placeholder="Password"
                    value={password}
                    onChangeText={setPassword}
                    autoCapitalize="none"
                    secureTextEntry
                />
                <TouchableOpacity style={styles.loginButton} onPress={handleLogin}>
                    <Text style={styles.buttonText}>Login</Text>
                </TouchableOpacity>
            </View>
        </>
    );
};

const styles = StyleSheet.create({
    welcome: {
        flexDirection: 'row', // Расположение букв в ряд
        justifyContent: 'center', // Центрирование текста
        alignItems: 'center', // Центрирование по вертикали
        marginTop: 20, // Отступ сверху
        padding: 10
    },
    letter: {
        fontSize: 32, // Размер шрифта
        color: '#2c5fec', // Цвет текста
        marginHorizontal: 2, // Отступ между буквами
    },


    buttonText: {
        color: 'white', // Text color
        fontWeight: 'bold', // Bold text
        textAlign: 'center', // Center text
    },
    loginButton: {
        height: 45, // Button height
        width: '100%', // Full width to center the button
        justifyContent: "center", // Center text vertically
        alignItems: "center", // Center text horizontally
        backgroundColor: "#2c5fec", // Button color
        borderRadius: 20, // Rounded corners
        marginTop: 10, // Space above the button
        shadowOffset: { width: 0, height: 2 }, // Shadow offset
        shadowOpacity: 0.2, // Shadow opacity
        shadowRadius: 4, // Shadow blur radius
        elevation: 3,
    },
    container: {
        padding: 20, // Padding for the container
        alignItems: 'center', // Center children horizontally
    },
    input: {
        height: 50, // Input height
        borderColor: '#ccc', // Border color
        borderWidth: 1, // Border width
        borderRadius: 8, // Rounded corners for input
        marginBottom: 10, // Bottom margin
        paddingHorizontal: 15, // Horizontal padding
        backgroundColor: '#fff', // Input background color
        shadowColor: '#000', // Shadow color
        shadowOffset: { width: 0, height: 2 }, // Shadow offset
        shadowOpacity: 0.2, // Shadow opacity
        shadowRadius: 4, // Shadow blur radius
        elevation: 3, // Elevation for Android
        width: '100%', // Full width for input fields
    },
    logo: {
        width: 350, // Logo width
        height: 150, // Logo height
        borderRadius: 20,
        marginTop: 20
    },
    imageContainer: {
        justifyContent: 'center', // Center image vertically
        alignItems: 'center', // Center image horizontally
    },
});

export default LoginInput;